<?php
/**
 * The template used for displaying credits
 *
 * @package PhotoFocus
 */
?>

<?php
/**
 * photofocus_credits hook
 * @hooked photofocus_footer_content - 10
 */
do_action( 'photofocus_credits' );
